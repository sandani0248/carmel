<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'deepred_carmelheightblog' );

/** MySQL database username */
define( 'DB_USER', 'deepred_carmelheightuser' );

/** MySQL database password */
define( 'DB_PASSWORD', 'c0Vw*?j}ikAf' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

define('DISALLOW_FILE_EDIT', true);

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'Vx3f~ZX;q-?VV^[#nSC_T%|+n+jqRa)`i&E3[f9 hyC4BbZSHhLE:$Bm$%:[(4Oq');
define('SECURE_AUTH_KEY',  '+nPyX$Y1?f.DFq)ll&+{A5f+WX)E`|<+_UzfPQj`we&_M1hl%Jg{M&Vzno|?omSf');
define('LOGGED_IN_KEY',    '>MKYxD+KS~w5,OO|8oHCxXFM+Z,Scw[rso&a6,?.6sdpdZ0[@}H|2xQ]eS-Q##Gd');
define('NONCE_KEY',        'S^|^}o>L6us+c-cz7+u.j4ZQztpz!wSHJ_)(Tgz@.-5n&?|EM}Y7?*(&|OIu`4Xp');
define('AUTH_SALT',        'n,`.e3:eG^$({7C CdW9Ij(n`Fv?tVT|fB;#|_VN!6I>z!+,zN]$sp<2Sr^.q~xL');
define('SECURE_AUTH_SALT', '_@W~]sW>mD%2svA+%&@ZwL:X~N#.3f&|l6E/]bvZ?kr%s+M`fD 1o6dNQmS&-6EX');
define('LOGGED_IN_SALT',   'cs3NmcR6{2[QZk/KM5N+|?qT|S<w5X4FpSk`Lo*vJu!A40FRXFAo&}30@V6qv_A?');
define('NONCE_SALT',       '23^bK-<$)*88Vt-#3VG}uE$5-^@)^BSC#}L*Z+em^D]Is=$GW*x-V~px$a^+W9Cm');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';

